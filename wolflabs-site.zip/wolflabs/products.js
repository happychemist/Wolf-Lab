// ── WOLF LABS · PRODUCT DATABASE ──
// Edit this file to update products across the entire site.
// Each product appears on the catalog page and gets its own detail page.

const PRODUCTS = [
  // ── PEPTIDES ──
  {
    id: 'retatrutide',
    name: 'Retatrutide',
    category: 'peptides',
    cas: '2381272-73-5',
    purity: '≥99%',
    icon: '🧬',
    shortDesc: 'Triple GIP/GLP-1/Glucagon receptor agonist. Next-generation metabolic research peptide.',
    fullDesc: 'Retatrutide (LY3437943) is a triple receptor agonist targeting GIP, GLP-1, and glucagon receptors simultaneously. Developed by Eli Lilly, it represents the most potent metabolic research peptide available. Phase 3 clinical trials demonstrated significant efficacy in metabolic research models.',
    tags: ['GIP/GLP-1/GCG', 'Metabolic', 'Lyophilized'],
    variants: [
      { label: '2mg vial', price: 35 },
      { label: '5mg vial', price: 75 },
      { label: '10mg vial', price: 130 },
    ],
    specs: [
      ['CAS Number', '2381272-73-5'],
      ['Molecular Formula', 'C222H377N65O65S'],
      ['Purity', '≥99% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
      ['Reconstitution', 'Bacteriostatic water'],
      ['Shelf Life', '24 months lyophilized'],
    ]
  },
  {
    id: 'bpc157-tb500',
    name: 'BPC-157 / TB-500',
    category: 'peptides',
    cas: '137525-51-0',
    purity: '≥98%',
    icon: '🔬',
    shortDesc: 'Dual blend: BPC-157 for tissue repair + TB-500 (Thymosin β4) for regeneration and recovery.',
    fullDesc: 'BPC-157 (Body Protection Compound) is a synthetic pentadecapeptide derived from a protective protein in gastric juice. TB-500 is a synthetic fraction of Thymosin Beta-4. Together they represent one of the most widely researched peptide combinations for tissue repair and recovery research.',
    tags: ['Tissue Repair', 'Dual Blend', 'Lyophilized'],
    variants: [
      { label: '5mg blend vial', price: 45 },
      { label: '10mg blend vial', price: 80 },
    ],
    specs: [
      ['BPC-157 CAS', '137525-51-0'],
      ['TB-500 CAS', '77591-33-4'],
      ['Blend Ratio', '1:1 (BPC-157 : TB-500)'],
      ['Purity', '≥98% HPLC each'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
      ['Reconstitution', 'Bacteriostatic water'],
    ]
  },
  {
    id: 'cjc-ipamorelin',
    name: 'CJC-1295 / Ipamorelin',
    category: 'peptides',
    cas: '863288-34-0',
    purity: '≥98%',
    icon: '⚗️',
    shortDesc: 'GH secretagogue blend. CJC-1295 (GHRH analog) combined with Ipamorelin (selective GHS).',
    fullDesc: 'CJC-1295 is a synthetic analog of growth hormone releasing hormone (GHRH) with an extended half-life due to drug affinity complex (DAC) technology. Ipamorelin is a selective growth hormone secretagogue. Combined, they synergistically promote GH release via dual receptor stimulation.',
    tags: ['GH Secretagogue', 'Dual Blend', 'Lyophilized'],
    variants: [
      { label: '5mg blend vial', price: 40 },
      { label: '10mg blend vial', price: 70 },
    ],
    specs: [
      ['CJC-1295 CAS', '863288-34-0'],
      ['Ipamorelin CAS', '170851-70-4'],
      ['Blend Ratio', '1:1'],
      ['Purity', '≥98% HPLC each'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },
  {
    id: 'pt141',
    name: 'PT-141 (Bremelanotide)',
    category: 'peptides',
    cas: '189691-06-3',
    purity: '≥99%',
    icon: '🔬',
    shortDesc: 'Melanocortin receptor agonist. Developed from Melanotan II. MC3R and MC4R activity.',
    fullDesc: 'PT-141 (Bremelanotide) is a synthetic melanocortin analogue that acts as an agonist at melanocortin receptors MC3R and MC4R. It is the research compound from which the FDA-approved drug Vyleesi (bremelanotide) was developed. Available as lyophilized powder for reconstitution.',
    tags: ['Melanocortin', 'MC3R/MC4R', 'Lyophilized'],
    variants: [
      { label: '10mg vial', price: 55 },
      { label: '25mg vial', price: 115 },
    ],
    specs: [
      ['CAS Number', '189691-06-3'],
      ['Molecular Formula', 'C50H68N14O10'],
      ['Purity', '≥99% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
      ['Reconstitution', 'Bacteriostatic water'],
    ]
  },
  {
    id: 'hcg',
    name: 'HCG (Human Chorionic Gonadotropin)',
    category: 'peptides',
    cas: '9002-61-3',
    purity: '≥98% IU verified',
    icon: '🧪',
    shortDesc: 'Glycoprotein hormone structurally similar to LH. HPG axis research and Leydig cell stimulation.',
    fullDesc: 'Human Chorionic Gonadotropin (HCG) is a glycoprotein hormone that mimics luteinizing hormone (LH) action at gonadal LH/CG receptors. Widely used in HPG axis research, it stimulates Leydig cell testosterone production and maintains testicular function. Provided as lyophilized powder with diluent.',
    tags: ['Glycoprotein', 'HPG Axis', 'Lyophilized'],
    variants: [
      { label: '5,000 IU vial', price: 45 },
      { label: '10,000 IU vial', price: 75 },
    ],
    specs: [
      ['CAS Number', '9002-61-3'],
      ['Potency', '≥5,000 IU/vial verified'],
      ['Purity', '≥98%'],
      ['Format', 'Lyophilized powder + diluent'],
      ['Storage', '2–8°C post-reconstitution'],
    ]
  },
  {
    id: 'ghkcu',
    name: 'GHK-Cu (Copper Peptide)',
    category: 'peptides',
    cas: '49557-75-7',
    purity: '≥98%',
    icon: '🔵',
    shortDesc: 'Glycyl-L-histidyl-L-lysine copper complex. Tissue remodeling, VEGF upregulation, collagen synthesis.',
    fullDesc: 'GHK-Cu is a naturally occurring copper complex of the tripeptide glycyl-histidyl-lysine. It has pleiotropic effects including stimulation of wound healing, attraction of immune cells, antioxidant and anti-inflammatory effects, stimulation of collagen and glycosaminoglycan synthesis, and activation of various growth factors including VEGF and PDGF.',
    tags: ['Copper Peptide', 'VEGF', 'Lyophilized'],
    variants: [
      { label: '50mg vial', price: 35 },
      { label: '200mg vial', price: 95 },
      { label: '500mg vial', price: 195 },
    ],
    specs: [
      ['CAS Number', '49557-75-7'],
      ['Molecular Formula', 'C14H23CuN6O4'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },
  {
    id: 'abaloparatide',
    name: 'Abaloparatide',
    category: 'peptides',
    cas: '247062-33-5',
    purity: '≥98%',
    icon: '🧬',
    shortDesc: 'Synthetic PTHrP analog. PTH1R agonist. Bone mineral density and osteoblast activity research.',
    fullDesc: 'Abaloparatide is a synthetic 34-amino acid peptide analog of parathyroid hormone-related protein (PTHrP). It is a selective activator of PTH1R that demonstrates preferential binding to the RG conformation of the receptor. The FDA-approved drug Tymlos was developed from this compound for osteoporosis. Research applications include bone metabolism and osteoblast activity studies.',
    tags: ['PTHrP Analog', 'PTH1R', 'Bone Research'],
    variants: [
      { label: '2mg vial', price: 50 },
      { label: '5mg vial', price: 110 },
    ],
    specs: [
      ['CAS Number', '247062-33-5'],
      ['Molecular Formula', 'C174H300N56O49'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },
  {
    id: 'dsip',
    name: 'DSIP (Delta Sleep-Inducing Peptide)',
    category: 'peptides',
    cas: '62568-57-4',
    purity: '≥98%',
    icon: '🌙',
    shortDesc: 'Nonapeptide with neuromodulatory properties. Sleep architecture, HPA axis modulation, antioxidant.',
    fullDesc: 'Delta Sleep-Inducing Peptide (DSIP) is a nonapeptide (Trp-Ala-Gly-Gly-Asp-Ala-Ser-Gly-Glu) originally isolated from the cerebral venous blood of rabbits. It has neuromodulatory properties, modulates basal corticotropin levels, and may normalize sleep architecture. Ongoing research explores its roles in stress response and antioxidant activity.',
    tags: ['Nonapeptide', 'Neuromodulatory', 'Lyophilized'],
    variants: [
      { label: '5mg vial', price: 40 },
      { label: '10mg vial', price: 70 },
    ],
    specs: [
      ['CAS Number', '62568-57-4'],
      ['Sequence', 'Trp-Ala-Gly-Gly-Asp-Ala-Ser-Gly-Glu'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },
  {
    id: 'na-semax',
    name: 'N-Acetyl Semax',
    category: 'peptides',
    cas: '80714-61-0',
    purity: '≥98%',
    icon: '🧠',
    shortDesc: 'Acetylated Semax analog with enhanced stability. BDNF/VEGF upregulation, neuroprotection research.',
    fullDesc: 'N-Acetyl Semax is a stabilized analog of Semax (ACTH 4-10 Pro-Gly-Pro) with an N-terminal acetyl group that protects against enzymatic degradation. It upregulates BDNF, VEGF, and other neurotrophic factors. Research applications include neuroprotection, cognitive function, and neurotrophic axis studies.',
    tags: ['Neuropeptide', 'BDNF', 'Lyophilized'],
    variants: [
      { label: '30mg vial', price: 55 },
      { label: '60mg vial', price: 95 },
    ],
    specs: [
      ['CAS Number', '80714-61-0'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
      ['Reconstitution', 'Bacteriostatic water or 0.9% saline'],
    ]
  },
  {
    id: 'selank',
    name: 'Selank',
    category: 'peptides',
    cas: '129954-34-3',
    purity: '≥98%',
    icon: '🧠',
    shortDesc: 'Anxiolytic heptapeptide. Tuftsin analog. GABAergic modulation, BDNF upregulation, stress research.',
    fullDesc: 'Selank is a synthetic analog of the endogenous regulatory tetrapeptide tuftsin (Thr-Lys-Pro-Arg) with the addition of Pro-Gly-Pro. Developed at the Institute of Molecular Genetics of the Russian Academy of Sciences, it has anxiolytic properties via GABAergic modulation without sedative effects. Research shows effects on serotonin and dopamine metabolism alongside BDNF upregulation.',
    tags: ['Heptapeptide', 'Anxiolytic', 'GABAergic'],
    variants: [
      { label: '5mg vial', price: 45 },
      { label: '10mg vial', price: 75 },
    ],
    specs: [
      ['CAS Number', '129954-34-3'],
      ['Sequence', 'Thr-Lys-Pro-Arg-Pro-Gly-Pro'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },
  {
    id: 'semax',
    name: 'Semax',
    category: 'peptides',
    cas: '80714-61-0',
    purity: '≥98%',
    icon: '🧠',
    shortDesc: 'Heptapeptide ACTH4-10 analog. BDNF/NGF upregulation, cognitive research, neuroprotection.',
    fullDesc: 'Semax (Met-Glu-His-Phe-Pro-Gly-Pro) is a synthetic heptapeptide based on the ACTH 4-10 fragment. Originally developed at the Institute of Molecular Genetics of Russia, it has been shown to upregulate BDNF, NGF, and other neurotrophic factors. N-Acetyl Semax is the more stable acetylated form.',
    tags: ['ACTH Analog', 'BDNF/NGF', 'Neuroprotection'],
    variants: [
      { label: '30mg vial', price: 45 },
      { label: '60mg vial', price: 80 },
    ],
    specs: [
      ['CAS Number', '80714-61-0'],
      ['Sequence', 'Met-Glu-His-Phe-Pro-Gly-Pro'],
      ['Purity', '≥98% HPLC'],
      ['Format', 'Lyophilized powder'],
      ['Storage', '-20°C, desiccated'],
    ]
  },

  // ── TOPICALS ──
  {
    id: 'ru58841',
    name: 'RU58841 5%',
    category: 'topicals',
    cas: '154992-24-2',
    purity: '≥99%',
    icon: '💧',
    shortDesc: 'Topical androgen receptor antagonist. 5% w/v solution in ethanol/PG/glycerin vehicle.',
    fullDesc: 'RU58841 is a non-steroidal anti-androgen that acts as a competitive antagonist at the androgen receptor. Unlike systemic anti-androgens, topical application results in rapid systemic metabolization, limiting systemic exposure. Formulated as a 5% w/v (50mg/mL) solution in a 70:25:5 ethanol/propylene glycol/glycerin vehicle for research applications.',
    tags: ['AR Antagonist', 'Topical', '5% w/v', 'HPLC Verified'],
    variants: [
      { label: '50mL bottle', price: 65 },
      { label: '100mL (2 × 50mL)', price: 115 },
    ],
    specs: [
      ['CAS Number', '154992-24-2'],
      ['Concentration', '5% w/v (50mg/mL)'],
      ['Volume', '50mL per bottle'],
      ['Vehicle', 'Ethanol / Propylene Glycol / Glycerin'],
      ['Purity', '≥99% HPLC (powder)'],
      ['Storage', 'Refrigerate 2–8°C, protect from light'],
      ['Shelf Life', '3 months from production date'],
      ['Container', 'Amber glass dropper bottle'],
    ]
  },
  {
    id: 'way316606',
    name: 'WAY-316606 2mg/mL',
    category: 'topicals',
    cas: '915759-45-4',
    purity: '≥99%',
    icon: '💧',
    shortDesc: 'SFRP1 inhibitor. Wnt/β-catenin pathway activator. 2mg/mL in DMSO/BAC water vehicle.',
    fullDesc: 'WAY-316606 is a selective inhibitor of Secreted Frizzled-Related Protein 1 (SFRP1), an endogenous inhibitor of Wnt signaling. By blocking SFRP1, WAY-316606 potentiates Wnt/β-catenin signaling in dermal papilla cells, promoting follicle cycling. Research by Manchester University demonstrated its activity in ex vivo human hair follicle models. Formulated as a 2mg/mL solution in DMSO/BAC water vehicle.',
    tags: ['SFRP1 Inhibitor', 'Wnt Pathway', 'Topical', '2mg/mL'],
    variants: [
      { label: '60mL bottle', price: 79 },
      { label: '120mL (2 × 60mL)', price: 145 },
    ],
    specs: [
      ['CAS Number', '915759-45-4'],
      ['Concentration', '2mg/mL'],
      ['Volume', '60mL per bottle'],
      ['Vehicle', 'DMSO / Bacteriostatic Water (70:30)'],
      ['Purity', '≥99% HPLC (powder)'],
      ['Storage', 'Refrigerate 2–8°C, protect from light'],
      ['Shelf Life', '6–8 weeks from production date'],
      ['Container', 'Amber glass bottle'],
    ]
  },
];

// ── UTILITY FUNCTIONS ──

function getProductById(id) {
  return PRODUCTS.find(p => p.id === id);
}

function getProductsByCategory(cat) {
  if (!cat || cat === 'all') return PRODUCTS;
  return PRODUCTS.filter(p => p.category === cat);
}

function getCategories() {
  const cats = [...new Set(PRODUCTS.map(p => p.category))];
  return cats;
}

// ── BUILD PRODUCT CARD HTML ──
function buildProductCard(product) {
  const defaultVariant = product.variants[0];
  return `
    <div class="product-card">
      <a href="product.html?id=${product.id}" style="text-decoration:none;color:inherit;">
        <div class="product-image">
          <div class="product-image-inner">
            <div class="product-icon">${product.icon}</div>
            <div class="product-cas">CAS ${product.cas}</div>
          </div>
        </div>
        <div class="product-body">
          <div class="product-name">${product.name}</div>
          <div class="product-meta">
            ${product.tags.map(t => `<span class="tag tag-${tagColor(t)}">${t}</span>`).join('')}
          </div>
          <div class="product-desc">${product.shortDesc}</div>
        </div>
      </a>
      <div class="product-footer">
        <div class="product-price">
          $${defaultVariant.price}
          <span class="unit">${defaultVariant.label}</span>
        </div>
        <button class="btn btn-primary" onclick="addToCart('${product.id}','${product.name}',${ defaultVariant.price },'${defaultVariant.label}')">Add</button>
      </div>
    </div>
  `;
}

function tagColor(tag) {
  const map = {
    'HPLC Verified': 'green', '≥99%': 'green', 'Lyophilized': 'grey',
    'Topical': 'blue', 'AR Antagonist': 'blue', 'SFRP1 Inhibitor': 'blue',
    'Neuroprotection': 'blue', 'BDNF': 'blue', 'Wnt Pathway': 'blue',
    'Metabolic': 'yellow', 'GH Secretagogue': 'yellow',
  };
  return map[tag] || 'grey';
}
