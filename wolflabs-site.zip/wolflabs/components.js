// ── WOLF LABS · SHARED COMPONENTS ──
// Injects nav, cart drawer, checkout modal, toast container, and footer into every page.
// Call injectComponents() at bottom of each page's <body>.

function injectComponents() {
  document.body.insertAdjacentHTML('afterbegin', navHTML());
  document.body.insertAdjacentHTML('beforeend', cartDrawerHTML());
  document.body.insertAdjacentHTML('beforeend', checkoutModalHTML());
  document.body.insertAdjacentHTML('beforeend', `<div class="toast-container" id="toast-container"></div>`);
  // Footer injected into .page-footer placeholder
  const footerEl = document.getElementById('page-footer');
  if (footerEl) footerEl.innerHTML = footerHTML();
}

function navHTML() {
  return `
  <nav class="nav">
    <div class="nav-logo">WOLF<span>LABS</span></div>
    <ul class="nav-links">
      <li><a href="index.html">Home</a></li>
      <li><a href="catalog.html">Catalog</a></li>
      <li><a href="about.html">About</a></li>
      <li><a href="faq.html">FAQ</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="nav-right">
      <button class="nav-cart" onclick="openCart()">
        Cart <span class="cart-count" id="nav-cart-count" style="display:none">0</span>
      </button>
    </div>
  </nav>`;
}

function cartDrawerHTML() {
  return `
  <div class="cart-overlay" id="cart-overlay"></div>
  <div class="cart-drawer" id="cart-drawer">
    <div class="cart-header">
      <h3>Cart</h3>
      <button class="cart-close" onclick="closeCart()">×</button>
    </div>
    <div class="cart-items" id="cart-items"></div>
    <div class="cart-empty" id="cart-empty" style="display:none">
      <span style="font-size:32px">🧪</span>
      <span>Your cart is empty</span>
      <a href="catalog.html" class="btn btn-ghost" onclick="closeCart()">Browse Catalog</a>
    </div>
    <div class="cart-footer" id="cart-footer" style="display:none">
      <div class="cart-total">
        <span>Total</span>
        <span class="cart-total-amount" id="cart-total-amount">$0.00</span>
      </div>
      <div class="cart-disclaimer">All products are for research use only. Not for human consumption.</div>
      <button class="btn btn-primary btn-lg" onclick="openCheckout()" style="width:100%;justify-content:center;">
        Checkout
      </button>
    </div>
  </div>`;
}

function checkoutModalHTML() {
  return `
  <div class="modal-overlay" id="checkout-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Complete Your Order</h3>
        <button class="modal-close" onclick="closeCheckout()">×</button>
      </div>
      <div class="modal-body">
        <div class="checkout-section-label">Order Summary</div>
        <div class="checkout-summary" id="checkout-summary-items"></div>

        <div class="checkout-section-label">Shipping Information</div>
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input class="form-input" id="checkout-name" type="text" placeholder="John Smith" autocomplete="name">
        </div>
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input class="form-input" id="checkout-email" type="email" placeholder="you@email.com" autocomplete="email">
        </div>
        <div class="form-group">
          <label class="form-label">Street Address</label>
          <input class="form-input" id="checkout-address" type="text" placeholder="123 Main St" autocomplete="street-address">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">City</label>
            <input class="form-input" id="checkout-city" type="text" placeholder="Chicago" autocomplete="address-level2">
          </div>
          <div class="form-group">
            <label class="form-label">State</label>
            <input class="form-input" id="checkout-state" type="text" placeholder="IL" maxlength="2" autocomplete="address-level1">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">ZIP Code</label>
            <input class="form-input" id="checkout-zip" type="text" placeholder="60601" autocomplete="postal-code">
          </div>
          <div class="form-group">
            <label class="form-label">Country</label>
            <select class="form-select" id="checkout-country">
              <option value="US">United States</option>
              <option value="CA">Canada</option>
              <option value="UK">United Kingdom</option>
              <option value="AU">Australia</option>
            </select>
          </div>
        </div>

        <div class="checkout-section-label">Payment Method</div>
        <div class="payment-method selected" data-method="btc" onclick="selectPayment('btc')">
          <div class="payment-method-icon">₿</div>
          <div class="payment-method-info">
            <div class="payment-method-name">Cryptocurrency</div>
            <div class="payment-method-sub">Bitcoin · USDC · USDT — Instant, private, secure</div>
          </div>
          <span class="payment-method-badge">Available</span>
        </div>
        <div class="payment-method" data-method="card" onclick="selectPayment('card')" style="opacity:0.5;cursor:not-allowed;" title="Coming soon">
          <div class="payment-method-icon">💳</div>
          <div class="payment-method-info">
            <div class="payment-method-name">Credit / Debit Card</div>
            <div class="payment-method-sub">Visa · Mastercard · Amex</div>
          </div>
          <span class="tag tag-grey" style="font-size:9px;">Coming Soon</span>
        </div>

        <div style="height:16px;"></div>
        <div class="checkout-section-label">Research Use Certification</div>
        <label class="tos-check">
          <input type="checkbox" id="tos-checkbox">
          <span class="tos-check-text">
            <strong>I confirm I am 18 years of age or older</strong> and a qualified researcher purchasing these products for legitimate scientific research purposes only. I acknowledge that all Wolf Labs products are sold <strong>for research use only and are not for human consumption</strong>. I have read and agree to the <a href="terms.html" target="_blank" style="color:var(--accent)">Terms of Sale</a> and <a href="privacy.html" target="_blank" style="color:var(--accent)">Privacy Policy</a>.
          </span>
        </label>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary btn-lg" id="place-order-btn" onclick="placeOrder()" style="justify-content:center;">
          Complete Order → Pay with Crypto
        </button>
        <div style="font-size:11px;color:var(--text3);text-align:center;line-height:1.5;">
          You will be redirected to our secure payment processor to complete your Bitcoin/USDC/USDT payment.
        </div>
      </div>
    </div>
  </div>`;
}

function footerHTML() {
  return `
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="footer-logo">WOLF LABS</div>
        <p class="footer-desc">Premium research compounds for qualified investigators. Third-party HPLC verified. Shipped with care from the United States.</p>
      </div>
      <div class="footer-col">
        <h4>Products</h4>
        <ul>
          <li><a href="catalog.html?cat=peptides">Peptides</a></li>
          <li><a href="catalog.html?cat=topicals">Topicals</a></li>
          <li><a href="catalog.html">Full Catalog</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Company</h4>
        <ul>
          <li><a href="about.html">About</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Policies</h4>
        <ul>
          <li><a href="terms.html">Terms of Sale</a></li>
          <li><a href="privacy.html">Privacy Policy</a></li>
          <li><a href="shipping.html">Shipping Policy</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p class="footer-disclaimer">
        <strong>Research Use Only.</strong> All products sold by Wolf Labs are intended for laboratory research purposes only. These products are not drugs, supplements, or food products and are not intended for human or veterinary use, diagnosis, or treatment. By purchasing from Wolf Labs, you confirm you are a qualified researcher and will use all products in compliance with applicable laws and regulations. Wolf Labs makes no representations regarding the safety or suitability of any product for human use.
      </p>
      <div class="footer-copy">© ${new Date().getFullYear()} Wolf Labs</div>
    </div>
  </div>`;
}
