// ── WOLF LABS · CART + CHECKOUT ENGINE ──

const BTCPAY_URL = 'https://YOUR-BTCPAY-SERVER-URL'; // Replace with your BTCPay Server URL

// ── CART STATE ──
let cart = JSON.parse(localStorage.getItem('wl-cart') || '[]');

function saveCart() {
  localStorage.setItem('wl-cart', JSON.stringify(cart));
  updateCartUI();
}

function cartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
}

function cartCount() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

// ── ADD TO CART ──
function addToCart(id, name, price, variant, qty = 1) {
  const key = id + '-' + variant;
  const existing = cart.find(i => i.key === key);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ key, id, name, price, variant, qty });
  }
  saveCart();
  showToast('✓', name + ' added to cart');
  openCart();
}

// ── REMOVE / UPDATE ──
function removeFromCart(key) {
  cart = cart.filter(i => i.key !== key);
  saveCart();
}

function updateQty(key, delta) {
  const item = cart.find(i => i.key === key);
  if (!item) return;
  item.qty = Math.max(1, item.qty + delta);
  saveCart();
}

// ── CART UI ──
function updateCartUI() {
  // Count badges
  document.querySelectorAll('.cart-count').forEach(el => {
    const count = cartCount();
    el.textContent = count;
    el.style.display = count > 0 ? 'inline-flex' : 'none';
  });

  // Cart items list
  const itemsEl = document.getElementById('cart-items');
  const emptyEl = document.getElementById('cart-empty');
  const footerEl = document.getElementById('cart-footer');
  if (!itemsEl) return;

  if (cart.length === 0) {
    itemsEl.innerHTML = '';
    if (emptyEl) emptyEl.style.display = 'flex';
    if (footerEl) footerEl.style.display = 'none';
    return;
  }

  if (emptyEl) emptyEl.style.display = 'none';
  if (footerEl) footerEl.style.display = 'flex';

  itemsEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-variant">${item.variant}</div>
        <div class="cart-item-price">$${(item.price * item.qty).toFixed(2)}</div>
        <div class="cart-item-controls">
          <button class="qty-btn" onclick="updateQty('${item.key}', -1)">−</button>
          <span class="qty-display">${item.qty}</span>
          <button class="qty-btn" onclick="updateQty('${item.key}', 1)">+</button>
        </div>
      </div>
      <button class="cart-remove" onclick="removeFromCart('${item.key}')" title="Remove">×</button>
    </div>
  `).join('');

  const totalEl = document.getElementById('cart-total-amount');
  if (totalEl) totalEl.textContent = '$' + cartTotal().toFixed(2);
}

// ── CART DRAWER OPEN/CLOSE ──
function openCart() {
  document.getElementById('cart-overlay')?.classList.add('open');
  document.getElementById('cart-drawer')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cart-overlay')?.classList.remove('open');
  document.getElementById('cart-drawer')?.classList.remove('open');
  document.body.style.overflow = '';
}

// ── CHECKOUT MODAL ──
function openCheckout() {
  if (cart.length === 0) { showToast('⚠', 'Your cart is empty'); return; }
  closeCart();
  populateCheckoutSummary();
  document.getElementById('checkout-modal')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCheckout() {
  document.getElementById('checkout-modal')?.classList.remove('open');
  document.body.style.overflow = '';
}

function populateCheckoutSummary() {
  const el = document.getElementById('checkout-summary-items');
  if (!el) return;
  el.innerHTML = cart.map(item => `
    <div class="checkout-summary-item">
      <span>${item.name} ${item.variant ? '· ' + item.variant : ''} × ${item.qty}</span>
      <span class="mono">$${(item.price * item.qty).toFixed(2)}</span>
    </div>
  `).join('') + `
    <div class="checkout-summary-item total">
      <span>Total</span>
      <span class="mono">$${cartTotal().toFixed(2)}</span>
    </div>
  `;
}

// ── PAYMENT METHOD SELECTION ──
let selectedPayment = 'btc';
function selectPayment(method) {
  selectedPayment = method;
  document.querySelectorAll('.payment-method').forEach(el => {
    el.classList.toggle('selected', el.dataset.method === method);
  });
}

// ── PLACE ORDER ──
async function placeOrder() {
  const tosChecked = document.getElementById('tos-checkbox')?.checked;
  if (!tosChecked) {
    showToast('⚠', 'Please accept the research use terms to continue');
    return;
  }

  const name = document.getElementById('checkout-name')?.value?.trim();
  const email = document.getElementById('checkout-email')?.value?.trim();
  const address = document.getElementById('checkout-address')?.value?.trim();
  const city = document.getElementById('checkout-city')?.value?.trim();
  const state = document.getElementById('checkout-state')?.value?.trim();
  const zip = document.getElementById('checkout-zip')?.value?.trim();

  if (!name || !email || !address || !city || !state || !zip) {
    showToast('⚠', 'Please fill in all shipping fields');
    return;
  }

  const btn = document.getElementById('place-order-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing...'; }

  if (selectedPayment === 'btc') {
    // BTCPay Server invoice creation
    try {
      const orderData = {
        amount: cartTotal().toFixed(2),
        currency: 'USD',
        metadata: {
          orderId: 'WL-' + Date.now(),
          buyerName: name,
          buyerEmail: email,
          items: cart.map(i => ({ name: i.name, variant: i.variant, qty: i.qty, price: i.price }))
        },
        checkout: {
          redirectURL: window.location.origin + '/order-complete.html',
          redirectAutomatically: true
        }
      };

      const response = await fetch(BTCPAY_URL + '/api/v1/stores/{YOUR-STORE-ID}/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'token {YOUR-API-KEY}' },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const invoice = await response.json();
        // Redirect to BTCPay checkout
        window.location.href = invoice.checkoutLink;
      } else {
        throw new Error('BTCPay connection failed');
      }
    } catch (err) {
      // Fallback: show BTCPay placeholder message
      closeCheckout();
      showBTCPayPlaceholder(name, email);
    }
  }

  if (btn) { btn.disabled = false; btn.textContent = 'Complete Order'; }
}

function showBTCPayPlaceholder(name, email) {
  // Temporary until BTCPay Server is configured
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay open';
  overlay.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>Complete Payment</h3>
        <button class="modal-close" onclick="this.closest('.modal-overlay').remove(); document.body.style.overflow=''">×</button>
      </div>
      <div class="modal-body">
        <div class="notice notice-blue" style="margin-bottom:20px;">
          <span>ℹ</span>
          <div>BTCPay Server is being configured. To complete your order, please contact us directly with your order details.</div>
        </div>
        <div class="checkout-summary" style="margin-bottom:20px;">
          <div class="checkout-section-label">Your Order</div>
          ${cart.map(i => `<div class="checkout-summary-item"><span>${i.name} · ${i.variant} ×${i.qty}</span><span class="mono">$${(i.price*i.qty).toFixed(2)}</span></div>`).join('')}
          <div class="checkout-summary-item total"><span>Total</span><span class="mono">$${cartTotal().toFixed(2)}</span></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <a href="mailto:orders@wolflabs.io?subject=Order from ${encodeURIComponent(name)}&body=Name: ${encodeURIComponent(name)}%0AEmail: ${encodeURIComponent(email)}%0AOrder Total: $${cartTotal().toFixed(2)}%0AItems: ${encodeURIComponent(cart.map(i=>i.name+' '+i.variant+' x'+i.qty).join(', '))}" 
             class="btn btn-primary btn-lg" style="text-align:center;justify-content:center;">
            Email Us Your Order
          </a>
        </div>
        <p style="font-size:11px;color:var(--text3);margin-top:12px;line-height:1.5;">We will respond within 24 hours with payment instructions. Cryptocurrency (BTC, USDC, USDT) accepted.</p>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
}

// ── TOAST ──
function showToast(icon, message) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'toast toast-success';
  toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'slideOut 0.3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
  updateCartUI();

  // Cart overlay click to close
  document.getElementById('cart-overlay')?.addEventListener('click', closeCart);

  // Set active nav link
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href')?.split('/').pop();
    if (href === path) a.classList.add('active');
  });

  // Payment method default selection
  document.querySelector('[data-method="btc"]')?.classList.add('selected');
});
